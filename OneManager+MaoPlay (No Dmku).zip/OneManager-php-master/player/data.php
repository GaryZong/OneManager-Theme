<?php
 $lele = array (
  'danmuon' => 'off',
  'color' => '#83639d',
  'logo' => '',
  'waittime' => '',
  'sendtime' => '',
  'dmliyi' => '',
  'dmrule' => '',
  'yjtest' => '关于播放器',
  'yjrule' => '',
  'pbgjz' => '',
  'ads' => 
  array (
    'pause' => 
    array (
      'state' => 'off',
      'bjt' => '',
      'pic' => '',
      'link' => '',
    ),
  ),
  'autoplay' => 'false',
  'bilibili' => '',
  'pmdzd' => '',
  'pmdzdy' => '',
  'json' => '1',
);
?>