<?php $configs = '
{
}
';
