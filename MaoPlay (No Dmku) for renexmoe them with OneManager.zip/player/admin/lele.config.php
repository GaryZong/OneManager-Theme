<?php
 $lele = array (
  'danmuon' => 'on',
  'color' => '#83639D',
  'logo' => '',
  'waittime' => '3',
  'sendtime' => '3',
  'dmliyi' => '弹幕礼仪',
  'dmrule' => 'https://www.5mrk.com',
  'yjtest' => '关于播放器',
  'yjrule' => 'https://wpa.qq.com/msgrd?v=3&uin=58249393&site=qq&menu=yes',
  'pbgjz' => '操ABCDEFGHIJKLMNOPQRSTUVWSYZabcdefghijklmnopqrstuvwsyz',
  'ads' => 
  array (
    'pause' => 
    array (
      'state' => 'on',
      'pic' => 'https://img10.360buyimg.com/ddimg/jfs/t1/133888/15/2798/61297/5ef5cd54E69f6dc60/93231446b43a6b1b.jpg',
      'link' => 'http://baidu.com',
    ),
  ),
  'autoplay' => 'true',
  'bilibili' => '',
  'pmdzd' => '',
  'pmdzdy' => '<br><marquee width=100% scrollamount=5> <FONT face=楷体_GB2312 color=#ff0000 size=3><STRONG>◆温馨警告:请自行辨别视频中的广告，以免上当受骗◆   <FONT face=楷体_GB2312 color=#0fb4ee size=3><STRONG>文明发弹幕，营造一个和谐的观影氛围</FONT></STRONG></a> </marquee>',
  'json' => '1',
);
?>