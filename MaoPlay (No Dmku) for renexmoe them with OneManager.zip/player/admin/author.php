<div class="panel panel-info">
  <div class="panel-heading">
    <h3 class="panel-title">开发者：Mao</h3>
  </div>
  <div class="panel-body"> 本后台由Mao网页制作站长独立开发，可管理网站会员、关键字屏蔽以及修改前台信息等等。若还想修改其他内容请直接修改前台代码，如果不了解请别动代码，以免程序出错。</div>
</div>